#ifndef __ISELEVATED_HPP__
#define __ISELEVATED_HPP__

bool IsElevated();

#endif
